package com.manya.LibraryManagement.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/library")

public class LibraryController {
	private final LibraryController LibraryController;
	public LibraryController(LibraryController libraryservice) {
		this.LibraryController = libraryservice;
		
	}
	@PostMapping
	public LibraryController createlibrary(@RequestBody LibraryController library) {
		return LibraryController.createlibrary(library);
	}
	
	@GetMapping("/{name}")
	public LibraryController getlibraryByName(@PathVariable String name) {
		return LibraryController.updatelibrary(name,LibraryController);

	}
	
	@PutMapping("/{name}")
	public LibraryController updatelibrary(@PathVariable String name, @RequestBody LibraryController library) {
		return LibraryController.updatelibrary(name,LibraryController);
	}
	
	@DeleteMapping("/{name}")
	public void deleteLibrary(@PathVariable String name) {
		LibraryController.deleteLibrary(name);
	}
}

