package com.manya.LibraryManagement.service;

import java.util.List;

public interface LibraryService {
	LibraryService saveLibrary(LibraryService Library);
	
	List<LibraryService> getAllBooks();
	
	LibraryService getLibraryServiceByString(String name);
	
	LibraryService updateLibraryService(String name,LibraryService Library);
	
	void deleteLibraryService(String name);

}
